
//Here 40 English braille characters are coded for testing of iRead.This program will be used in 
//conjunction with a python script to read a paragraph of English on a 40 character braille disc. The input is text from the python script 
//and the output is the rotation of the motor based on the characters from the text.

//Ver b1.0 -created by Anupama Thomas on February 2022
//*****************************************************************************

#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/adc.h"
#include "utils/uartstdio.h"
#include "utils/uartstdio.c"
#include "driverlib/rom.h"
void rotateccw(int stepnum);
void rotatesimply(int stepnum);
void delayMs(int n);
int stepcounter,currentstep,currentposn,startposn,newposn;


//*****************************************************************************

//! - UART0 peripheral
//! - GPIO Port A peripheral (for UART0 pins)
//! - UART0RX - PA0
//! - UART0TX - PA1
//
//*****************************************************************************
//
// Configure the UART and perform reads and writes using polled I/O.
//
//*****************************************************************************
int main(void)
   {
	 char cThisChar;
	 
	
    // Set the clocking to run directly from the external crystal/oscillator.
    // TODO: The SYSCTL_XTAL_ value must be changed to match the value of the
    // crystal on your board.
    //
    ROM_SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN |
                   SYSCTL_XTAL_16MHZ);

    // Enable the peripherals used by this example.
    // The UART itself needs to be enabled, as well as the GPIO port
    // containing the pins that will be used.
    
     ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
     ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	 // Enable the GPIO port that is used for the on-board LED.
    
     ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
     ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);//
    //
    
   ROM_GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1 );//LED display
   ROM_GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_3|GPIO_PIN_2 | GPIO_PIN_1 | GPIO_PIN_0 );//to motor windings
    //
    // Configure the GPIO pin muxing for the UART function.
    
    //
     ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
     ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
    // Since GPIO A0 and A1 are used for the UART function, they must be
    // configured for use as a peripheral function (instead of GPIO).
   
    //
     ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    // Configure the UART for 115,200, 8-N-1 operation.
    // This function uses SysCtlClockGet() to get the system clock
    // frequency.  This could be also be a variable or hard coded value
    // instead of a function call.
    //
     ROM_UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,
                        (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
                         UART_CONFIG_PAR_NONE));
    
		/* make PB6 an input pin -connected to position sensor output*/
		ROM_GPIOPinTypeGPIOInput(GPIO_PORTB_BASE, GPIO_PIN_6 );
		
		//rotate every 5 steps while checking if the disc has come to the starting position ie where the space character is positioned.
		while(GPIOPinRead(GPIO_PORTB_BASE, GPIO_PIN_6)==0)
						 {
							rotatesimply(newposn=5); 
							
						 }
		
		 ROM_UARTCharPut(UART0_BASE, '*');
   
while(1)
     {
		     ////@@@@@@@@@@@
				 UARTStdioInit(0); //use UART0, 115200
         UARTprintf("Enter text: ");
		     ROM_SysCtlDelay(SysCtlClockGet() / (12));
		     
        // Read a character using the blocking read function.  This function
        // will not return until a character is available.
        //
        cThisChar = UARTCharGet(UART0_BASE);
        // Write the same character using the blocking write function.  This
        // function will not return until there was space in the FIFO and
        // the character is written.
        //
        UARTCharPut(UART0_BASE, cThisChar);
			switch(cThisChar)
			{
				 currentposn=200;
				
			case' '://space--whenever pressed,disc comes to start position;;
				  rotateccw(newposn=200);//
			    //GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3,0);
          break ;	
      case'a':
			case'A':
					 //Turn by required number of steps
			     rotateccw(newposn=5);
			     break;	

      case'b':
			case'B':
					 //Turn by required number of steps
			     rotateccw(newposn=10);
			     break;	
			
			case'c':
			case'C':
					 //Turn by required number of steps
			     rotateccw(newposn=15);//200=360deg,90deg=50
			     break;	
			
      case'd':
			case'D':
					 //Turn by required number of steps
			     rotateccw(newposn=20);
			     break;	

      case'e':
			case'E':
					 //Turn by required number of steps
			     rotateccw(newposn=25);
			     break;
 
      case'f':
			case'F':
					 //Turn by required number of steps
			     rotateccw(newposn=30);
			     break;	
    
      case'g':
			case'G':
					 //Turn by required number of steps
			     rotateccw(newposn=35);
			     break;		
      
      case'h':
			case'H':
					 //Turn by required number of steps
			     rotateccw(newposn=40);
			     break;

      case'i':
			case'I':
					 //Turn by required number of steps
			     rotateccw(newposn=45);
			     break;	

      case'j':
			case'J':
					 //Turn by required number of steps
			     rotateccw(newposn=50);
			     break;	

      case'k':
			case'K':
					 //Turn by required number of steps
			     rotateccw(newposn=55);
			     break;				
			
			case'l':
			case'L':
					 //Turn by required number of steps
			     rotateccw(newposn=60);
			     break;	
			
			case'm':
			case'M':
					 //Turn by required number of steps
			     rotateccw(newposn=65);
			     break;	
			
			case'n':
			case'N':
					 //Turn by required number of steps
			     rotateccw(newposn=70);
			     break;

      case'0':
			case'O':
					 //Turn by required number of steps
			     rotateccw(newposn=75);
			     break;	
			
      case'p':
			case'P':
					 //Turn by required number of steps
			     rotateccw(newposn=80);
			     break;			

      case'q':
			case'Q':
					 //Turn by required number of steps
			     rotateccw(newposn=85);
			     break;	

      case'r':
			case'R':
					 //Turn by required number of steps
			     rotateccw(newposn=90);
			     break;	

      case's':
			case'S':
					 //Turn by required number of steps
			     rotateccw(newposn=95);
			     break;	

      case't':
			case'T':
					 //Turn by required number of steps
			     rotateccw(newposn=100);
			     break;	

      case'u':
			case'U':
					 //Turn by required number of steps
			     rotateccw(newposn=105);
			     break;	

       case'v':
			case'V':
					 //Turn by required number of steps
			     rotateccw(newposn=110);
			     break;	

        case'w':
			case'W':
					 //Turn by required number of steps
			     rotateccw(newposn=115);
			     break;	
       
      case'x':
			case'X':
					 //Turn by required number of steps
			     rotateccw(newposn=120);
			     break;	

       case'y':
			case'Y':
					 //Turn by required number of steps
			     rotateccw(newposn=125);
			     break;	

      case'z':
			case'Z':
					 //Turn by required number of steps
			     rotateccw(newposn=130);
			     break;
         //number indicator  is 135			
	       //capital letter indicator ....dot 6...140
			   //......steps 140
		      
			case','://COMMA
					 //Turn by required number of steps
			     rotateccw(newposn=145);
			     break;	


			case':'://COLON
					 //Turn by required number of steps
			     rotateccw(newposn=150);
			     break;	


			case';'://SEMICOLON
					 //Turn by required number of steps
			     rotateccw(newposn=155);
			     break;	


			case'.'://PERIOD
					 //Turn by required number of steps
			     rotateccw(newposn=160);
			     break;	


			case'-'://HYPHEN
					 //Turn by required number of steps
			     rotateccw(newposn=165);
			     break;	

      case'?': //QUESTION MARK
			case'"'://OPEN QUOTE
					 //Turn by required number of steps
			     rotateccw(newposn=170);
			     break;	

  			//case' " '://CLOSED QUOTE
					 //Turn by required number of steps
			    // rotateccw(newposn=175);//200=360deg,90deg=50
//			     break;	


			case'!'://5
					 //Turn by required number of steps
			     rotateccw(newposn=180);
			     break;	

      
			case'/'://SLASH
					 //Turn by required number of steps
			     rotateccw(newposn=185);
			     break;	

      
//			case''':  //APOSTROPHE
//					 //Turn by required number of steps
//			     rotateccw(newposn=190);//200=360deg,90deg=50
//			     break;	

      case'(':
			case')'://5
					 //Turn by required number of steps
			     rotateccw(newposn=195);
			     break;				
		
		
			    }
				
		    
				}					
 }
	
 //Rotate function where motor rotates at a 3 msec delay between steps while reading text
void rotateccw(int stepnum)
   {
		 stepcounter =0;
		 
		  if (newposn <= currentposn)//("=" is if same key is pressed it rotates 200steps)
		    stepnum = (200 - (currentposn-newposn));
		 else 
		    stepnum = (newposn- currentposn);			
				
		    currentposn = newposn;// important step...keeps a tab on the posn of letter pressed
		 		 
	  //while(stepcounter <= stepnum)
	while(stepcounter < stepnum)
	       {
	  switch(currentstep)
	        {
		case (0):
		//GPIOB->DATA = 0x09;//1001//FULLSTEP CW direction 0x09,0x03,0x06,0x0c
		ROM_GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3| GPIO_PIN_2| GPIO_PIN_1|GPIO_PIN_0, GPIO_PIN_3|0|0|GPIO_PIN_0 );
		break;
		
		case (1):
		//GPIOB->DATA = 0x03;//0011
		ROM_GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3| GPIO_PIN_2| GPIO_PIN_1|GPIO_PIN_0, 0|0|GPIO_PIN_1|GPIO_PIN_0 );
		break;
		
		case (2):
		//GPIOB->DATA = 0x06;//0110
		ROM_GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3| GPIO_PIN_2| GPIO_PIN_1|GPIO_PIN_0, 0|GPIO_PIN_2|GPIO_PIN_1|0 );
		break;
		
		case (3):
		//GPIOB->DATA = 0x0C;//1100
		ROM_GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3| GPIO_PIN_2| GPIO_PIN_1|GPIO_PIN_0, GPIO_PIN_3|GPIO_PIN_2|0|0 );
		break;
		      }
	      
		    stepcounter = stepcounter++;
				//currentstepsave=currentstep;//saving the current step
		    currentstep= currentstep++;//ccw,cw++,currentstep--
		    if (currentstep == 4 )//4,-1
				   {
             //currentstepsave=0;
						 currentstep=0;
           }//0,3	
					 
	   		//delayMs(2);//fastest possible time
				//ROM_SysCtlDelay(SysCtlClockGet() / (100*3));
				ROM_SysCtlDelay(SysCtlClockGet()*3 / (3*1000));//2ms delay on osc,*3 is a 3 msec delay
								
      }
  }
	
	
//Motor rotates at a 20msec delay between steps while reaching home position
	 void rotatesimply(int stepnum)
	 {
		 stepcounter =0;
		 while(stepcounter < stepnum)
	       {
	  switch(currentstep)
	        {
		case (0):
		//GPIOB->DATA = 0x09;//1001//FULLSTEP CW direction 0x09,0x03,0x06,0x0c
		ROM_GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3| GPIO_PIN_2| GPIO_PIN_1|GPIO_PIN_0, GPIO_PIN_3|0|0|GPIO_PIN_0 );
		break;
		
		case (1):
		//GPIOB->DATA = 0x03;//0011
		ROM_GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3| GPIO_PIN_2| GPIO_PIN_1|GPIO_PIN_0, 0|0|GPIO_PIN_1|GPIO_PIN_0 );
		break;
		
		case (2):
		//GPIOB->DATA = 0x06;//0110
		ROM_GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3| GPIO_PIN_2| GPIO_PIN_1|GPIO_PIN_0, 0|GPIO_PIN_2|GPIO_PIN_1|0 );
		break;
		
		case (3):
		//GPIOB->DATA = 0x0C;//1100
		ROM_GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3| GPIO_PIN_2| GPIO_PIN_1|GPIO_PIN_0, GPIO_PIN_3|GPIO_PIN_2|0|0 );
		break;
		      }
	      
		    stepcounter = stepcounter++;
				currentstep= currentstep++;//ccw,cw++,currentstep--
		    if (currentstep == 4 )//4,-1
				   {
            currentstep=0;
           }//0,3	
					 
	   		ROM_SysCtlDelay(SysCtlClockGet()*20 / (3*1000));//20msec delay between steps
								
      }
		 
		 
		 
	 }
/////////////////////////



		 

 
	
  


